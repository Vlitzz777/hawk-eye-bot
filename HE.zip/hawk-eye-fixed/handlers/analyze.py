import logging

from aiogram import Bot, Router, Dispatcher, types
from aiogram.filters import Command, CommandObject

from analysis.backtest import get_backtest_stats
from analysis.confluence import evaluate_confluence
from analysis.indicators import calculate_indicators
from analysis.market_data import fetch_ohlcv
from database.sqlite_db import UserDB
from utils.formatting import format_signal_message

router = Router(name="analyze")
logger = logging.getLogger(__name__)


@router.message(Command("analyze"))
async def cmd_analyze(
    message: types.Message,
    command: CommandObject,
    db: UserDB,
    bot: Bot,
):
    # In aiogram 3.x, args come from the CommandObject, NOT message.command.
    # message.command is not a real attribute; using it raises AttributeError.
    args = (command.args or "").strip().upper() if command else ""

    if not args:
        await message.answer(
            "❌ Please provide a valid symbol.\n"
            "Example: `/analyze ETHUSDT`",
            parse_mode="Markdown",
        )
        return

    pair = args
    # Be lenient: if user typed just "BTC" or "ETH", auto-append "USDT"
    if "/" not in pair and not pair.endswith(("USDT", "USDC", "USD", "BUSD", "EUR")):
        pair = pair + "USDT"

    processing = await message.reply(
        f"⏳ Analyzing *{pair}* across 1H / 4H / 1D…",
        parse_mode="Markdown",
    )

    try:
        user_prefs = await db.get_or_create_user(message.from_user.id)
        risk_pct = user_prefs["risk_percent"]

        # Fetch & enrich each timeframe with indicators
        ohlcv_data = await fetch_ohlcv(pair, ["1h", "4h", "1d"])
        for tf in ohlcv_data:
            ohlcv_data[tf] = calculate_indicators(ohlcv_data[tf])

        current_price = float(ohlcv_data["1h"]["close"].iloc[-1])

        # Confluence engine
        signal = evaluate_confluence(ohlcv_data)

        if not signal:
            await processing.edit_text(
                f"📉 *{pair}*\n\n"
                "Insufficient confluence for a high-probability setup at the moment.\n"
                "Waiting for stronger alignment across timeframes.",
                parse_mode="Markdown",
            )
            return

        # Backtest win-rate on similar 1H setups
        wr = await get_backtest_stats(pair)

        msg_text = format_signal_message(
            signal, pair, current_price, wr, risk_pct
        )
        await bot.send_message(
            message.chat.id, msg_text, parse_mode="Markdown"
        )
        await processing.delete()

    except Exception as e:
        logger.error("Analysis failed for %s: %s", pair, e, exc_info=True)
        try:
            await processing.edit_text(
                "⚠️ Failed to fetch market data or compute signal.\n"
                f"Details: `{type(e).__name__}: {str(e)[:200]}`",
                parse_mode="Markdown",
            )
        except Exception:
            await message.answer(
                f"⚠️ Analysis failed: `{type(e).__name__}`",
                parse_mode="Markdown",
            )


def register_analyze_handlers(dp: Dispatcher, db: UserDB):
    dp.include_router(router)
