from aiogram import Router, Dispatcher, types
from aiogram.filters import Command, CommandObject

from database.sqlite_db import UserDB
from utils.formatting import format_settings_message

router = Router(name="settings")


@router.message(Command("settings"))
async def cmd_settings(message: types.Message, db: UserDB):
    prefs = await db.get_or_create_user(message.from_user.id)
    await message.answer(
        format_settings_message(prefs), parse_mode="Markdown"
    )


@router.message(Command("setpair"))
async def cmd_setpair(message: types.Message, command: CommandObject, db: UserDB):
    args = (command.args or "").strip().upper() if command else ""

    if not args or len(args) < 5 or not args.endswith("USDT"):
        await message.answer(
            "❌ Invalid format. Usage: `/setpair BTCUSDT`",
            parse_mode="Markdown",
        )
        return

    await db.update_pair(message.from_user.id, args)
    prefs = await db.get_or_create_user(message.from_user.id)
    await message.answer(
        format_settings_message(prefs), parse_mode="Markdown"
    )


@router.message(Command("risk"))
async def cmd_risk(message: types.Message, command: CommandObject, db: UserDB):
    args = (command.args or "").strip() if command else ""
    try:
        risk = float(args)
    except (ValueError, TypeError):
        await message.answer(
            "❌ Usage: `/risk <0.1-5.0>`",
            parse_mode="Markdown",
        )
        return

    try:
        await db.update_risk(message.from_user.id, risk)
    except ValueError:
        await message.answer(
            "❌ Risk must be between 0.1% and 5.0%.",
            parse_mode="Markdown",
        )
        return

    prefs = await db.get_or_create_user(message.from_user.id)
    await message.answer(
        format_settings_message(prefs), parse_mode="Markdown"
    )


def register_settings_handlers(dp: Dispatcher, db: UserDB):
    dp.include_router(router)
