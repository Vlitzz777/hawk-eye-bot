from aiogram import Router, Dispatcher, types
from aiogram.filters import Command

from database.sqlite_db import UserDB

router = Router(name="start")


@router.message(Command("start"))
async def cmd_start(message: types.Message, db: UserDB):
    # Defensive: from_user can be None for channel posts; skip registration then.
    if message.from_user is not None:
        await db.get_or_create_user(message.from_user.id)

    await message.answer(
        "👋 Welcome to *Crypto Signal Bot*!\n\n"
        "I provide deterministic, confluence-backed trading signals across "
        "multiple timeframes (1H / 4H / 1D).\n\n"
        "*Commands:*\n"
        "/analyze <SYMBOL> — Get technical analysis (e.g. /analyze BTCUSDT)\n"
        "/setpair <SYMBOL> — Set your default pair\n"
        "/risk <0.1-5.0> — Set risk % per trade\n"
        "/settings — Show your current preferences\n"
        "/help — Show this help message\n\n"
        "📊 All signals are data-driven. No guesswork, no hallucinations.",
        parse_mode="Markdown",
    )


@router.message(Command("help"))
async def cmd_help(message: types.Message):
    await message.answer(
        "*Crypto Signal Bot — Help*\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        "/analyze <SYMBOL> — Run multi-timeframe confluence analysis.\n"
        "/setpair <SYMBOL> — Set default trading pair (must end with USDT).\n"
        "/risk <0.1-5.0> — Set risk percentage per trade.\n"
        "/settings — View your current configuration.\n"
        "/start — Re-show the welcome screen.\n"
        "/help — This message.\n\n"
        "Example: `/analyze ETHUSDT`",
        parse_mode="Markdown",
    )


def register_start_handlers(dp: Dispatcher):
    dp.include_router(router)
