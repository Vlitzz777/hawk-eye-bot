def format_signal_message(
    signal: dict,
    pair: str,
    current_price: float,
    backtest_wr: float,
    risk_pct: float,
) -> str:
    """Generate a clean, professional trading signal message.

    Critical bug fixed: `entry_zone` was computed as
        f"{current_price * (1.0 if is_long else 1.0):,.2f}"
    which:
      (a) is just a comma-formatted STRING (e.g. "65,432.10") and
      (b) was then used in arithmetic: `tp3 - entry_zone` -> TypeError
          every time a signal fired, crashing the bot mid-send.
    Now `entry_zone` is a plain float.
    """
    is_long = signal["direction"] == "Long"
    direction_emoji = "🟢" if is_long else "🔴"

    entry_zone = float(current_price)
    tp1 = current_price * (1.0 + 0.015 if is_long else 1.0 - 0.015)
    tp2 = current_price * (1.0 + 0.030 if is_long else 1.0 - 0.030)
    tp3 = current_price * (1.0 + 0.050 if is_long else 1.0 - 0.050)
    sl = current_price * (1.0 - 0.020 if is_long else 1.0 + 0.020)

    # Risk/reward using TP3 as the final target
    if sl != entry_zone:
        rr = round(abs((tp3 - entry_zone) / (entry_zone - sl)), 2)
    else:
        rr = "N/A"

    per_tf = signal.get("per_timeframe", {})
    tf_lines = ""
    if per_tf:
        tf_lines = "\n".join(
            f"   • {tf.upper()}: {('+' if v >= 0 else '')}{v}"
            for tf, v in sorted(per_tf.items())
        ) + "\n"

    msg = (
        f"📊 *{pair} Technical Analysis*\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"{direction_emoji} Direction: *{signal['direction']}*\n"
        f"💰 Entry Zone: {entry_zone:,.2f}\n"
        f"🎯 TP1: {tp1:,.2f} | 🎯 TP2: {tp2:,.2f} | 🎯 TP3: {tp3:,.2f}\n"
        f"🛑 Stop-Loss: {sl:,.2f}\n"
        f"⚖️ Risk/Reward: 1:{rr}\n"
        f"🔒 Confidence: *{signal['confidence']}%* "
        f"(Score: {signal['weighted_score']})\n"
        f"{tf_lines}"
        f"📈 Recent Win-Rate (similar setups): {backtest_wr}%\n"
        f"💸 Suggested Position Size: {risk_pct}% of capital per trade\n\n"
        f"⚠️ _No signal is 100% guaranteed. Past performance is not indicative "
        f"of future results. Trade at your own risk._"
    )
    return msg


def format_settings_message(user_prefs: dict) -> str:
    return (
        f"⚙️ *Settings*\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔹 Preferred Pair: `{user_prefs['preferred_pair']}`\n"
        f"🛡️ Risk per Trade: `{user_prefs['risk_percent']}%`\n\n"
        f"Use `/analyze <SYMBOL>` to get signals."
    )
