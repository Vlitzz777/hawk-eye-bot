// API base: same origin in production, but allow override via ?api= for dev
const API_BASE = new URLSearchParams(location.search).get('api') || '';

// DOM Elements
const cfgForm = document.getElementById('cfgForm');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const statusBadge = document.getElementById('statusBadge');
const logContent = document.getElementById('logContent');

let statusInterval;

async function api(path, opts = {}) {
    try {
        const res = await fetch(`${API_BASE}${path}`, opts);
        if (!res.ok) {
            const err = await res.json().catch(() => ({ detail: res.statusText }));
            throw new Error(err.detail || `HTTP ${res.status}`);
        }
        return await res.json();
    } catch (err) {
        console.error('API call failed:', path, err);
        throw err;
    }
}

// Load initial state
async function loadState() {
    try {
        const data = await api('/status');
        updateStatus(data.running, data.exchange);
        if (data.last_signal) {
            appendLog(data.last_signal, 'signal');
        }
    } catch (err) {
        updateStatus(false, '—');
    }
}

function updateStatus(isRunning, exchange) {
    statusBadge.className = `badge ${isRunning ? 'online' : 'offline'}`;
    statusBadge.innerHTML = `<i class="fa-solid fa-${isRunning ? 'circle-check' : 'circle-xmark'}"></i> ${
        isRunning ? `Online • ${String(exchange || '').toUpperCase()}` : 'Offline'
    }`;
    startBtn.disabled = isRunning;
    stopBtn.disabled = !isRunning;
}

async function pollLogs() {
    try {
        const data = await api('/logs');
        if (data.logs && data.logs.length > 0) {
            logContent.innerHTML = '';
            data.logs.forEach(line => {
                let type = 'info';
                if (line.includes('📊') || line.includes('🎯')) type = 'signal';
                else if (line.toLowerCase().includes('error') || line.includes('⚠️')) type = 'error';
                appendLog(line, type);
            });
            logContent.scrollTop = logContent.scrollHeight;
        }
    } catch (err) { /* ignore transient errors */ }
}

function appendLog(text, type = '') {
    const el = document.createElement('span');
    el.className = `log ${type}`;
    el.textContent = `[${new Date().toLocaleTimeString()}] ${text}\n`;
    logContent.appendChild(el);
}

// --- Event listeners -------------------------------------------------------

cfgForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(cfgForm);
    const data = Object.fromEntries(formData.entries());

    try {
        await api('/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
        alert('✅ Configuration saved. Restart bot to apply.');
    } catch (err) {
        alert(`❌ Failed to save config: ${err.message}`);
    }
});

startBtn.addEventListener('click', async () => {
    try {
        await api('/start', { method: 'POST' });
        appendLog('Bot start requested.', 'info');
        loadState();
    } catch (err) {
        alert(`⚠️ Could not start bot: ${err.message}`);
    }
});

stopBtn.addEventListener('click', async () => {
    if (!confirm('Stop the trading bot?')) return;
    try {
        await api('/stop', { method: 'POST' });
        appendLog('Bot stop requested.', 'info');
        loadState();
    } catch (err) {
        alert(`⚠️ Could not stop bot: ${err.message}`);
    }
});

// --- Init ------------------------------------------------------------------
loadState();
pollLogs();
statusInterval = setInterval(loadState, 3000);
setInterval(pollLogs, 2000);
